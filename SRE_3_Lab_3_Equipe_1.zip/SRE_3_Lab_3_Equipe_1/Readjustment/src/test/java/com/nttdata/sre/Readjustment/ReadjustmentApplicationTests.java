package com.nttdata.sre.Readjustment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadjustmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
