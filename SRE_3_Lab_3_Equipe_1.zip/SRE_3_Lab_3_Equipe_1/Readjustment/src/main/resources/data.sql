INSERT INTO tb_Department (id, office, initial_salary, percentage_increase, new_salary) VALUES (1,'Trainee', 1100, 100,0);
INSERT INTO tb_Department (id, office, initial_salary, percentage_increase, new_salary) VALUES (2,'Junior', 2300, 100,0);
INSERT INTO tb_Department (id, office, initial_salary, percentage_increase, new_salary) VALUES (3,'Engineer', 4300, 100,0);